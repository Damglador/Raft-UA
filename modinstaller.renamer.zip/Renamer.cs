using RaftModLoader;
using UnityEngine;
using HMLLibrary;
using System.Text;
using I2.Loc;
using Mono.Cecil.Cil;
using System.IO;
using System;

public class Renamer : Mod
{
    static bool ExtraSettingsAPI_Loaded = false;
    static bool StartUpPending = true;
    public static string dataFolder = HLib.path_modsFolder + "\\ModData\\Renamer\\";

    public void Start()
    {
        Log("Mod Renamer has been loaded!");
    }

    public void Update()
    {
        if (StartUpPending)
        {
            StartUpPending = false;

            if (!ExtraSettingsAPI_Loaded)
            {
                ErrorNotification("Renamer Mod can't start.\nThe Extra Settings Mod is missing.");
                return;
            }

            if (ExtraSettingsAPI_GetCheckboxState("loadOnStartCheckbox") && !ExtraSettingsAPI_GetInputValue("filenameInput").IsNullOrEmpty())
            {
                if (!ImportLocalizationFromCSV(ExtraSettingsAPI_GetInputValue("filenameInput")))
                    ErrorNotification($"Unable to load {ExtraSettingsAPI_GetInputValue("filenameInput")}");
                else
                    SuccessNotification($"Loaded {ExtraSettingsAPI_GetInputValue("filenameInput")}");
            }
        }
    }

    public void OnModUnload()
    {
        Log("Mod Renamer has been unloaded!");
    }

    public void ExtraSettingsAPI_ButtonPress(string name)
    {
        if (name == "loadCsvButton")
        {
            if (!ImportLocalizationFromCSV(ExtraSettingsAPI_GetInputValue("filenameInput")))
                ErrorNotification($"Unable to load {ExtraSettingsAPI_GetInputValue("filenameInput")}");
            else
                SuccessNotification($"Loaded {ExtraSettingsAPI_GetInputValue("filenameInput")}");
        }
    }

    [ConsoleCommand(name: "ExportLocalizationToCSV", docs: "This command will export whole loaded localizations to LanguageSourceData.csv inside ModData folder.")]
    public static void ExportLocalizationToCSVCommand()
    {
        // Raft stores all their localizations inside Sources[0], no need to check others
        if (!Directory.Exists(dataFolder))
        {
            Directory.CreateDirectory(dataFolder);
            File.WriteAllText(dataFolder + $"LanguageSourceData.csv", LocalizationManager.Sources[0].Export_CSV(null, ';'), Encoding.UTF8);
        }
        else
        {
            File.WriteAllText(dataFolder + $"LanguageSourceData.csv", LocalizationManager.Sources[0].Export_CSV(null, ';'), Encoding.UTF8);
        }
    }

    [ConsoleCommand(name: "ImportLocalizationFromCSV", docs: "File must be in ModData folder and seperator must be ';'.\nUsage: ImportLocalizationFromCSV filename")]
    public static void ImportLocalizationFromCSVCommand(string[] args)
    {
        if (args == null || args.Length == 0)
        {
            Debug.LogError("Invalid argument.");
            Debug.LogError("Type 'help ImportLocalizationFromCSV'");
            return;
        }

        if (!ImportLocalizationFromCSV(args[0]))
            Debug.LogError("Type 'help ImportLocalizationFromCSV'");
    }

    public static bool ImportLocalizationFromCSV(string filename)
    {
        if (filename.IsNullOrEmpty())
        {
            Debug.LogError("Invalid filename.");
            return false;
        }

        if (!File.Exists(dataFolder + filename))
        {
            Debug.LogError($"No file with name {filename} in ModData.");
            return false;
        }

        Debug.Log(LocalizationManager.Sources[0].Import_CSV(null, File.ReadAllText(dataFolder + filename, Encoding.UTF8), eSpreadsheetUpdateMode.Merge, ';'));
        LocalizationManager.LocalizeAll(true);
        return true;
    }

    public static HNotification ErrorNotification(string message)
    {
        return FindObjectOfType<HNotify>().AddNotification(HNotify.NotificationType.normal, message, 10, HNotify.ErrorSprite);
    }

    public static HNotification SuccessNotification(string message)
    {
        return FindObjectOfType<HNotify>().AddNotification(HNotify.NotificationType.normal, message, 5, HNotify.CheckSprite);
    }

    // ExtraSettings Section
    public static bool ExtraSettingsAPI_GetCheckboxState(string SettingName) => false;
    public static string ExtraSettingsAPI_GetInputValue(string SettingName) => "";

    public void ExtraSettingsAPI_Load()
    {
    }
}